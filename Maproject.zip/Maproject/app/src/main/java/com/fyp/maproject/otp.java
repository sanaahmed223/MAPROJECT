package com.fyp.maproject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class otp extends AppCompatActivity {
    EditText otp1, otp2, otp3, otp4, otp5, otp6;
    Button verify, resend;
    private ProgressBar progressBar;
    TextView status;
    TextView mobilenumber;
    private int position = 0;
    TextView changenumber;
    String getotpbackend;
    private int progressstatus = 100;
    private int progressstatussss = 60;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);
        pro();
        resend = findViewById(R.id.resend);
        resend.setVisibility(View.GONE);

        resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pro();
                PhoneAuthProvider.getInstance().verifyPhoneNumber("+92" + getIntent().getStringExtra("mobileno"), 60, TimeUnit.SECONDS, otp.this, new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    @Override
                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                    }

                    @Override
                    public void onVerificationFailed(@NonNull FirebaseException e) {
                        Toast.makeText(otp.this, "tttt", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCodeSent(@NonNull String otp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {

                        getotpbackend = otp;
                    }
                });

            }
        });
        otp1 = findViewById(R.id.otp1);
        otp2 = findViewById(R.id.otp2);
        otp3 = findViewById(R.id.otp3);
        otp4 = findViewById(R.id.otp4);
        otp5 = findViewById(R.id.otp5);
        otp6 = findViewById(R.id.otp6);

        mobilenumber = findViewById(R.id.mobile);
        mobilenumber.setText(String.format("+92-%s", getIntent().getStringExtra("mobile")));


        progressBar = findViewById(R.id.progressBar);


        changenumber = findViewById(R.id.Changenumber);
        changenumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(otp.this, sendotp.class);
                intent.putExtra("mobile", getIntent().getStringExtra("mobile"));
                startActivity(intent);
            }
        });



        getotpbackend = getIntent().getStringExtra("getotp");

        verify = findViewById(R.id.verify);
        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!otp1.getText().toString().trim().isEmpty() && !otp2.getText().toString().trim().isEmpty() && !otp3.getText().toString().trim().isEmpty() && !otp4.getText().toString().trim().isEmpty() && !otp5.getText().toString().trim().isEmpty() && !otp6.getText().toString().trim().isEmpty()) {
                    String enterotp = otp1.getText().toString() + otp2.getText().toString() + otp3.getText().toString() + otp4.getText().toString() + otp5.getText() + otp6.getText();
                    if (getotpbackend != null) {
                        PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.getCredential(getotpbackend, enterotp);
                        FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Intent intent = new Intent(otp.this, resgistration.class);
                                    startActivity(intent);

                                } else {
                                    Toast.makeText(otp.this, "Invalid or expired otp", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }

            }
        });

        otp1.addTextChangedListener(textWatcher);
        otp2.addTextChangedListener(textWatcher);
        otp3.addTextChangedListener(textWatcher);
        otp4.addTextChangedListener(textWatcher);
        otp5.addTextChangedListener(textWatcher);
        otp6.addTextChangedListener(textWatcher);
        showkeybord(otp1);


    }

    private void pro() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (progressstatus > 0) {
                    progressstatus -= 1;
                    progressstatussss -= 1;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {

                            progressBar.setProgress(progressstatus);
                            status = findViewById(R.id.ptext);
                            status.setText(progressstatussss + "");
                            if (progressstatus == 0) {
                                verify.setVisibility(View.GONE);
                                resend.setVisibility(View.VISIBLE);
                            }

                        }


                    });

                    try {
                        Thread.sleep(350);

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }


    public void showkeybord(EditText otped) {
        otped.requestFocus();
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.showSoftInput(otped, InputMethodManager.SHOW_IMPLICIT);

    }

    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void afterTextChanged(Editable editable) {
            if (editable.length() > 0) {
                if (position == 0) {
                    position = 1;
                    showkeybord(otp2);
                } else if (position == 1) {
                    position = 2;
                    showkeybord(otp3);
                } else if (position == 2) {
                    position = 3;
                    showkeybord(otp4);
                } else if (position == 3) {
                    position = 4;
                    showkeybord(otp5);
                } else if (position == 4) {
                    position = 5;
                    showkeybord(otp6);

                }

            }
        }
    };

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_DEL) {
            if (position == 6) {
                position = 5;
                showkeybord(otp6);
            } else if (position == 5) {
                position = 4;
                showkeybord(otp5);
            } else if (position == 4) {
                position = 3;
                showkeybord(otp4);
            } else if (position == 3) {
                position = 2;
                showkeybord(otp3);
            } else if (position == 2) {
                position = 1;
                showkeybord(otp2);
            } else if (position == 1) {
                position = 0;
                showkeybord(otp1);
            }
            return true;
        } else {
            return super.onKeyUp(keyCode, event);
        }
    }
}