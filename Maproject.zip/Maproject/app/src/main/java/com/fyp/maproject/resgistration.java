package com.fyp.maproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class resgistration extends AppCompatActivity {
    private FirebaseAuth mAuth;
    EditText name, customernumber, customeraddress, password, confirmpassword, nic;
    Button registration;
    TextView TV;
    boolean passwordvisible;
    boolean cpasswordvisible;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resgistration);
        name = findViewById(R.id.name);
        customernumber = findViewById(R.id.customernumber);
        customeraddress = findViewById(R.id.customeraddress);
        password = findViewById(R.id.password);
        confirmpassword = findViewById(R.id.cpassword);
        nic = findViewById(R.id.nic);
        mAuth = FirebaseAuth.getInstance();

        TV = findViewById(R.id.tv);
        TV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(resgistration.this, signin.class);
                startActivity(i);
            }
        });

        password.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                final int Right = 2;

                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    if (motionEvent.getRawX() >= password.getRight()-password.getCompoundDrawables()[Right].getBounds().width()) {
                        int selection = password.getSelectionEnd();
                        if (passwordvisible) {
                            password.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_baseline_visibility_off_24, 0);
                            password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            passwordvisible = false;
                        } else {
                            password.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_baseline_visibility_24, 0);
                            password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                            passwordvisible = true;
                        }
                        password.setSelection(selection);
                        return true;
                    }
                }

                return false;
            }
        });
        confirmpassword.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                final int Right = 2;
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    if (motionEvent.getRawX() >= confirmpassword.getRight()-confirmpassword.getCompoundDrawables()[Right].getBounds().width()) {
                        int selection = confirmpassword.getSelectionEnd();
                        if (cpasswordvisible) {
                            confirmpassword.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_baseline_visibility_off_24, 0);
                            confirmpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            cpasswordvisible = false;
                        } else {
                            confirmpassword.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_baseline_visibility_24, 0);
                            confirmpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                            cpasswordvisible = true;
                        }
                        confirmpassword.setSelection(selection);
                        return true;
                    }
                }

                return false;
            }
        });

        registration = findViewById(R.id.registration);
        registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // getting data from our edit text.
                String userName = name.getText().toString();
                String pwd = password.getText().toString();
                String cnfPwd = confirmpassword.getText().toString();
                String nicno = nic.getText().toString();
                String customerno = customernumber.getText().toString();
                String customeradd = customeraddress.getText().toString();


                // checking if the password and confirm password is equal or not.
                if (!pwd.equals(cnfPwd))
                {
                    Toast.makeText(resgistration.this, "password & confirm password is not same", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(userName))
                {
                    Toast.makeText(resgistration.this, "Please enter full name!.", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(customerno))
                {
                    Toast.makeText(resgistration.this, "Please enter customer number!", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(customeradd))
                {
                    Toast.makeText(resgistration.this, "Please enter customer address", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(pwd) )
                {
                    Toast.makeText(resgistration.this, "Please enter password!", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(cnfPwd))
                {
                    Toast.makeText(resgistration.this, "Please enter confirm password!", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(nicno))
                {
                    Toast.makeText(resgistration.this, "Please enter cnic number!", Toast.LENGTH_SHORT).show();
                }
                else if (!(pwd.length() ==6)){
                    Toast.makeText(resgistration.this, "password must be at least of 6 character", Toast.LENGTH_SHORT).show();
                }
                else if (!(customerno.length() ==10)){
                    Toast.makeText(resgistration.this, "customer number should not be less then 10 digits", Toast.LENGTH_SHORT).show();
                }
                else if(!(nicno.length() ==13)){
                    Toast.makeText(resgistration.this, "CNIC number should no be less then 13 digits!", Toast.LENGTH_SHORT).show();
                }
                else {

                    // on below line we are creating a new user by passing email and password.
                    mAuth.createUserWithEmailAndPassword(userName, pwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            // on below line we are checking if the task is success or not.
                            if (task.isSuccessful()) {

                                // in on success method we are hiding our progress bar and opening a login activity.
                                Toast.makeText(resgistration.this, "User Registered..", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(resgistration.this, signin.class);
                                startActivity(i);
                                finish();
                            } else {

                                // in else condition we are displaying a failure toast message.
                                Toast.makeText(resgistration.this, "Fail to register user..", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
    }
}