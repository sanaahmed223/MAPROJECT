package com.fyp.maproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class sendotp extends AppCompatActivity {
    EditText mobileno;
    Button sendotp;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sendotp);
        mobileno = findViewById(R.id.mobilennnnnn);
        sendotp = findViewById(R.id.sendotp);
        progressBar = findViewById(R.id.progressBar2);
        String regexStr = "^[0-9]{10}$";
        mobileno.setText(getIntent().getStringExtra("mobile"));
        sendotp.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (!mobileno.getText().toString().trim().isEmpty() && (mobileno.getText().toString().trim()).length() == 10) {
                    if ((mobileno.getText().toString().trim()).matches(regexStr) == true) {

                        progressBar.setVisibility(View.VISIBLE);
                        PhoneAuthProvider.getInstance().verifyPhoneNumber("+92" + mobileno.getText().toString(), 60, TimeUnit.SECONDS, com.fyp.maproject.sendotp.this, new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                progressBar.setVisibility(View.GONE);
                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                progressBar.setVisibility(View.GONE);
                                Toast.makeText(sendotp.this, "tttt", Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                progressBar.setVisibility(View.GONE);
                                Intent intent = new Intent(com.fyp.maproject.sendotp.this, otp.class);
                                intent.putExtra("mobile", mobileno.getText().toString());
                                intent.putExtra("getotp",s);
                                startActivity(intent);
                            }
                        });

                    } else {
                        Toast.makeText(sendotp.this, "Please enter valid phone number", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(sendotp.this, "Phone should no be less then 11 digits", Toast.LENGTH_SHORT).show();

                }

            }
        });

    }
}

